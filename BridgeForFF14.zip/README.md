# FF14 OptiScaler + GITC-Uplift 共存部署包（合规版）

- 生成时间：2026-10-26 16:41
- 状态基线：`snapshots/2026-10-26-PREUPSCALE`（**超分前 NR** 已验证生效）
- 上游：OptiScaler DLSS5 分支 @ `fc702f8c` + 本仓库 5 行 null-guard 补丁

## ⚠️ 本包不含 NVIDIA 组件（重要）

`nvngx_dlssnr.dll`（Uplift 的 NR 模型，约 254 MB）是 **NVIDIA 专有二进制，
禁止再分发**，因此本包不含它。你需要自己准备：

1. **从你自己的 NVIDIA 驱动里取**
   驱动安装目录（版本号随驱动而变），或 `C:\Windows\System32\DriverStore\FileRepository\`
   下搜 `nvngx_dlssnr.dll`；
2. **从已经装了 DLSS5 / Neural Rendering 的游戏目录里复制**；
3. 或从你信任的渠道自行获取。

放到游戏目录的 **`game\GITC-Uplift\nvngx_dlssnr.dll`**（该子目录需自己建，
放别处也行——OptiScaler 会递归搜索子目录）。
Uplift 的 addon 自带说明文件 `Put nvngx_dlssnr.dll here.txt` 也指向这里。

同理，DLSS 超分本体 `nvngx_dlss.dll`、插帧 `nvngx_dlssg.dll` 也不随包分发。

## 用法

把本包内文件解压到 FF14 的 **`最终幻想XIV\game\`** 目录（与 `ffxiv_dx11.exe` 同级），
覆盖同名文件：

| 文件 | 作用 | MD5 |
|---|---|---|
| `dxgi.dll` | OptiScaler 代理（补丁版） | `486f58b3eccb4bfa0ee1642332ab1de1` |
| `ReShade64.dll` | ReShade 本体 | `b645f1019abc7d0a11be4d923205660f` |
| `gitc-uplift.addon64` | Uplift ReShade addon | `06f530962704ee6e266338c6c08d561f` |
| `OptiScaler.ini` | OptiScaler 配置（忠实镜像） | `509b6b557fbdc63d9ece1222a2839cb8` |
| `OptiScaler.ini.hardened` | 同上 + 封死 F6 双绑（推荐） | `a69445d9f6b42de43ddcca94ffaa1bf1` |
| `ReShade.ini` | `[Uplift]` 段配置 | `c5b55168d0eca1e040efea02025a4310` |

**`OptiScaler.ini` 还是 `OptiScaler.ini.hardened`？**
两个内容几乎一样，差别只在 `[DlssNr]` 段：

| | `CompareKey` | `ToggleKey` | `Enabled` |
|---|---|---|---|
| `OptiScaler.ini`（原样） | `auto`（→ F6） | `auto` | 缺省 |
| `OptiScaler.ini.hardened` | `-1` | `-1` | `false` |

F6 同时被 OptiScaler 自带 NR 和 Uplift 的 `EnableKey=117` 绑定。
按下去会以 Vanilla 模式强制打开 Opti 的 NR，而 Uplift 的 NR 也在跑
→ **双 NR 必崩**。若你打算用 F6 开关 Uplift NR，**请用 hardened 版本**
（把 `OptiScaler.ini.hardened` 改名成 `OptiScaler.ini` 再放进去）。

## 这套配置在做什么

`Dx11Upscaler = dlss`（原生 DX11 DLSS 超分，不建 dx11on12 桥）
+ `[FrameGen] Enabled = true` / `FGOutput = XeFG`（XeFG 插帧）
+ `[Uplift] PreUpscale = 1`（**NR 跑在超分之前**，网络输入是渲染分辨率而非输出分辨率）
+ `[Uplift] PresentWithFrameGen = 1`（插帧活跃时接管 OptiScaler 的 skip-NR 分支）
+ `[UpscaleRatio] UpscaleRatioOverrideEnabled = true` + `Value = 1.5`（固定超分比例，抗回弹）
+ `[DRS] DrsMin/MaxOverrideEnabled = true`（钉住 FF14 的动态分辨率）
+ `[Menu] ExtendedLimits = true`

三者同时运行：DLSS 超分 + XeFG 插帧 + Uplift NR，互不遮挡。

## 怎么确认 NR 真的开了

看 `game\ReShade.log`（**不要看 UI 提示，UI 会骗人**）：

```
[Uplift] Placement: before upscaling (Balanced, 1920x1080 -> 2880x1620)
[Uplift] NR trigger: before upscaling
[Uplift] NR feature created 1920x1080 (D3D12, preset request 2, ...)
[Uplift] NR running: N frames ... in 60 s
```

出现 `before upscaling` 且 `NR feature created` 的尺寸**等于渲染分辨率**就是成功。
若是 `Placement: after DLSS` 且尺寸等于输出分辨率，说明还在超分后跑。

## 换机必查：NVIDIA 驱动自带的插帧会和 XeFG 抢通道

第二台机（RTX 4060 Ti）上出现过"启动即崩"：原因是 NVIDIA 驱动附赠的
**Smooth Motion / 驱动级插帧**（`NvPresent64.dll`）与 OptiScaler 的 XeFG 抢
NvAPI/Reflex 通道 → 两个 fake nvapi 打架 → `libxess_fg` 崩。

**处理：在 NVIDIA 控制面板 / NVIDIA App 里把驱动自带的插帧关掉**，
不要删或改名那个 dll。

## 许可

- 补丁 / 配置 / 文档：**GPL-3.0**（派生自 OptiScaler）
- `dxgi.dll`：GPL-3.0，对应源码 = 上游 `fc702f8c` + `patches/0001-*.patch`
- `ReShade64.dll`：**BSD-3-Clause**
- `gitc-uplift.addon64`：**MIT** © 2026 Hussain Abdullah
- NVIDIA 组件：**不随本包分发**，用户自备

完整文本见 `Licenses/` 与仓库根 `NOTICE.md`。
